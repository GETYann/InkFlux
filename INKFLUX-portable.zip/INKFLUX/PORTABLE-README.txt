INKFLUX - Version portable
==========================

Lancement : double-cliquer sur inkflux.exe

Ce dossier est autonome : vous pouvez le copier sur une clé USB
ou n'importe quel ordinateur, il fonctionne tel quel.

Données
-------
La présence du fichier « portable.flag » active le mode portable :
toutes les données de l'application sont enregistrées dans le
dossier « userdata/ » à côté de l'exécutable :

    userdata/stock_imprimante.db   base de données (stock, services,
                                   mouvements, imprimantes, employés)
    userdata/*.hive                réglages (langue, etc.)

Pour créer une sauvegarde, copiez simplement le dossier « userdata/ ».
Pour repasser en mode classique (données dans les dossiers
utilisateur de Windows), supprimez le fichier « portable.flag ».

Prérequis
---------
Aucune installation requise. Windows 10/11 64 bits.
